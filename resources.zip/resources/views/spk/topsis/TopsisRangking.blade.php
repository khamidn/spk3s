@extends("admin.layout")
@section("content")
<div class="block-header">
	<h2>HASIL AKHIR</h2>
	<hr>
</div>

<form class="form-horizontal" role="form" method="POST" action="{{route('keputusan.simpan')}}">
{{csrf_field()}}

<div class="row">
	<div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
		<div class="card">
			<div class="header">
				<h2>RANGKING SISWA</h2>
				<!-- <a href="{{route('export.alternatif')}}"> -->
					<ul class="header-dropdown m-r--5">
						 <li class="dropdown">
						 	<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="material-icons">more_vert</i>
						 	</a>
						 	<ul class="dropdown-menu pull-right">
						 		<li><a href="{{route('export.alternatif')}}"><i class="material-icons col-indigo">file_download</i>
						 			Unduh Rangking</a>
						 		</li>
						 	</ul>
								
						 </li>			
					</ul>
			</div>

			
			<div class="body">	
				<div class="table-responsive">
				<table class="table table-striped js-basic-example dataTable">
					<thead>
						<tr>
							<th width="10%">No</th>
							<th width="10%">NISN</th>
							<th width="50%">Nama</th>
							<th width="10%">Nilai</th>
							<th width="20%">Keputusan</th>
						</tr>
					</thead>
					<tbody>
						@php 
							$noUtama9=0;
							$noUrut=1;
							foreach($rangking as $rank){
							$noUtama9+=1;
							echo '<tr>';
							echo '<td>'.$noUrut++.'</td>';
							echo '<td>'.$rank->nisn.'</td>';
							echo '<td>'.$rank->nama_siswa.'</td>';
							echo '<td><input style="width:100%;"type="text" id="rangking-k'.$noUtama9.'" class="form-control" value="'.$rank->nilai_akhir_ci.'" readonly="" /> </td>';

							if(Auth::check()){
								if(Auth::user()->hasRole('admin')){
									echo '<td>';
										echo '<select name="keputusan-k'.$noUtama9.'" class="form-control show-tick" disabled="">';
											$status = $rank->keputusan;
												if($status==1){
													echo '<option value="0">Belum Naik Kelas</option>';
													echo '<option value="1" selected="selected">Naik Kelas</option>';
												}
												else{
													echo '<option value="0" selected="selected">Belum Naik Kelas</option>';
													echo '<option value="1">Naik Kelas</option>';
												}
										echo '</select>';
									 echo '</td>';
								}
								else{
									echo '<td>';
										echo '<select name="keputusan-k'.$noUtama9.'" class="form-control show-tick">';
											$status = $rank->keputusan;
												if($status==1){
													echo '<option value="0">Belum Naik Kelas</option>';
													echo '<option value="1" selected="selected">Naik Kelas</option>';
												}
												else{
													echo '<option value="0" selected="selected">Belum Naik Kelas</option>';
													echo '<option value="1">Naik Kelas</option>';
												}
										echo '</select>';
									 echo '</td>';
									
								}
							}
							echo '</tr>';
							}
						@endphp
					</tbody>
				</table>
				</div>

				@if(Auth::check())
					@if(Auth::user()->hasRole('wali_kelas'))
					<div class="row">
						<div class="col-lg-3">
							<button type="submit" id="simpanKeputusan" class="btn btn-success waves-effect" style="margin-top: 20px;">Simpan Keputusan</button>
						</div>
					</div>
					@endif
				@endif
			</div>

		</div>
	</div>
</div>
</form>
@endsection

